package com.example._68.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/places")
@CrossOrigin(origins = "*")
public class PlaceController {

    @Autowired
    private PlaceService placeService;

    @GetMapping("/getAllPlace")
    public ResponseEntity<List<Place>> getAllPlace() {
        try {
            List<Place> places = placeService.getAllPlaces();
            return ResponseEntity.ok(places);
        } catch (Exception e) {
            return ResponseEntity.internalServerError().build();
        }
    }

    @GetMapping("/popular")
    public ResponseEntity<List<Place>> getPopularPlaces() {
        try {
            List<Place> popularPlaces = placeService.getPopularPlaces();
            return ResponseEntity.ok(popularPlaces);
        } catch (Exception e) {
            return ResponseEntity.internalServerError().build();
        }
    }
}

